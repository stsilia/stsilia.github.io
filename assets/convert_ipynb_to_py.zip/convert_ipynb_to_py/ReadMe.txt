Author: Styliani Tsilia
Version: 1.0
Description:
This workflow converts Jupyter notebooks (.ipynb) into clean, readable Python scripts (.py) using a custom Jinja2 template. 

-------

How to Use:

1. Copy script.tpl and clean_script.tpl into the same folder as your .ipynb file. 

2. Open a terminal, go into that folder and run nbconvert:
   jupyter nbconvert --to script --template=clean_script.tpl your_notebook.ipynb
   
3. All done! Your converted .py file will appear in the same folder. 



Bonus: 
The template simply inserts an extra blank line in the final script to mark where the notebook changes cells, but this is customizable - simply adjust within script.tpl the line marked with the comment {# Change of cell marker #}